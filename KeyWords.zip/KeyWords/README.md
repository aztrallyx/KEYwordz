# KeyWords

App Android local para practicar contraseñas. Sin permisos (sin internet), teclado propio, bóveda cifrada.

## Compilar en GitHub
1. Crea un repositorio PRIVADO en GitHub.
2. Sube TODO el contenido de esta carpeta (incluida `.github/workflows/build.yml`).
   Si la carpeta `.github` no se sube desde el navegador, crea el archivo a mano:
   "Add file > Create new file", nombre `.github/workflows/build.yml`, y pega el contenido del yml.
3. Pestaña **Actions** > "Build KeyWords APK" (corre solo al subir; o "Run workflow").
4. Al terminar, entra a la ejecución y descarga el artefacto **KeyWords-apk** (zip con el .apk).
5. Instala el .apk en tu celular (permite "instalar apps desconocidas").

## Notas
- El workflow FALLA a propósito si el APK llegara a tener permiso de internet.
- La llave de firma se guarda en la caché de GitHub. Si pasa más de ~7 días sin compilar, la caché puede borrarse,
  el APK nuevo tendrá otra firma y habrá que desinstalar la app antes de instalarlo (pierdes los datos locales).
  Por eso: EXPORTA UN RESPALDO cifrado (Settings) antes de actualizar.
- Si olvidas la contraseña maestra no hay forma de recuperar nada.
