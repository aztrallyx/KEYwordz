package com.keywords.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.UUID

// ------------------------------------------------------------ Auth

@Composable
fun AuthScreen() {
    val scope = rememberCoroutineScope()
    val pw = remember { TextBuf() }
    val pw2 = remember { TextBuf() }
    var reveal by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val importing = App.pendingImport != null
    val setup = !App.vaultExists() && !importing

    LaunchedEffect(Unit) { App.kb.target = pw }

    fun submit() {
        App.kb.target = null
        error = null
        if (setup) {
            if (pw.text.length < 8) {
                error = "Usa al menos 8 caracteres."
            } else if (pw.text != pw2.text) {
                error = "Las contraseñas no coinciden."
            } else {
                busy = true
                scope.launch { App.setup(pw.text); busy = false }
            }
        } else {
            busy = true
            scope.launch {
                val ok = App.unlock(pw.text)
                busy = false
                if (!ok) error = "Contraseña incorrecta o respaldo inválido."
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        Text("KeyWords", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            when {
                setup -> "Crea tu contraseña maestra. NO hay forma de recuperarla si la olvidas."
                importing -> "Respaldo cargado. Escribe la contraseña maestra de ese respaldo."
                else -> "Escribe tu contraseña maestra."
            },
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        SField("Contraseña maestra", pw, secret = true, reveal = reveal)
        if (setup) {
            SField("Repite la contraseña maestra", pw2, secret = true, reveal = reveal)
            StrengthMeter(pw.text)
        }
        TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Ocultar" else "Mostrar") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { submit() },
            enabled = !busy && pw.text.isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "Trabajando…" else if (setup) "Crear bóveda" else "Desbloquear") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { App.launchImport() }, modifier = Modifier.fillMaxWidth()) {
            Text("Importar respaldo cifrado")
        }
        if (importing) {
            TextButton(onClick = { App.pendingImport = null }) { Text("Cancelar importación") }
        }
    }
}

// ------------------------------------------------------------ Home

@Composable
fun HomeScreen() {
    Scaffold(
        bottomBar = {
            if (App.kb.target == null) {
                NavigationBar {
                    Tab.values().forEach { t ->
                        NavigationBarItem(
                            selected = App.tab == t,
                            onClick = { App.tab = t },
                            icon = { Text(t.icon) },
                            label = { Text(t.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            when (App.tab) {
                Tab.ACCOUNTS -> AccountsTab()
                Tab.PRACTICE -> PracticeTab()
                Tab.STATS -> StatsTab()
                Tab.SETTINGS -> SettingsTab()
            }
        }
    }
}

@Composable
fun AccountsTab() {
    val groups = App.accounts
        .groupBy { it.category.ifBlank { "Sin categoría" } }
        .toSortedMap(String.CASE_INSENSITIVE_ORDER)
    LazyColumn(contentPadding = PaddingValues(12.dp)) {
        item {
            Button(onClick = { App.screen = Screen.Edit(null) }, modifier = Modifier.fillMaxWidth()) {
                Text("＋ Agregar cuenta")
            }
        }
        if (App.accounts.isEmpty()) {
            item { Text("Aún no hay cuentas. Agrega la primera.", modifier = Modifier.padding(top = 16.dp)) }
        }
        groups.forEach { (cat, list) ->
            item(key = "h$cat") {
                Text(
                    cat,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                )
            }
            items(list.sortedBy { it.name.lowercase() }, key = { it.id }) { a ->
                Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { App.screen = Screen.Edit(a.id) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text(a.name, fontWeight = FontWeight.Bold)
                        if (a.username.isNotBlank()) Text(a.username, fontSize = 13.sp)
                        Text(
                            (if (a.strict) "🔒 Estricta (solo hash)" else "🔐 Cifrada") + "  ·  " +
                                (if (a.seen > 0) "${a.correct * 100 / a.seen}% al primer intento (${a.correct}/${a.seen})" else "sin practicar"),
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------ Edit

@Composable
fun EditScreen(id: String?) {
    val scope = rememberCoroutineScope()
    val existing = remember { App.accounts.firstOrNull { it.id == id } }
    val name = remember { TextBuf(existing?.name ?: "") }
    val user = remember { TextBuf(existing?.username ?: "") }
    val cat = remember { TextBuf(existing?.category ?: "") }
    val pw = remember { TextBuf(existing?.password ?: "") }
    var strict by remember { mutableStateOf(existing?.strict ?: false) }
    var reveal by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun close() {
        App.kb.target = null
        App.screen = Screen.Home
    }
    BackHandler { close() }

    fun finish(a: Account) {
        App.upsert(a)
        close()
    }

    fun save() {
        val n = name.text.trim()
        if (n.isEmpty()) { error = "El nombre es obligatorio."; return }
        val base = Account(
            id = existing?.id ?: UUID.randomUUID().toString(),
            name = n, username = user.text.trim(), category = cat.text.trim(),
            strict = false, password = "", salt = "", hash = "",
            seen = existing?.seen ?: 0, correct = existing?.correct ?: 0
        )
        val p = pw.text
        if (!strict) {
            if (p.isEmpty()) { error = "La contraseña es obligatoria."; return }
            finish(base.copy(password = p))
        } else if (p.isEmpty()) {
            if (existing != null && existing.strict) {
                finish(base.copy(strict = true, salt = existing.salt, hash = existing.hash))
            } else {
                error = "La contraseña es obligatoria."
            }
        } else {
            busy = true
            scope.launch {
                val a = App.makeStrict(base, p)
                busy = false
                finish(a)
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(if (existing == null) "Nueva cuenta" else "Editar cuenta", style = MaterialTheme.typography.headlineMedium)
        SField("Nombre (ej. Instagram)", name)
        SField("Usuario / correo", user)
        SField("Categoría", cat)
        val cats = App.accounts.map { it.category }.filter { it.isNotBlank() }.distinct().sorted()
        if (cats.isNotEmpty()) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                cats.forEach { c -> AssistChip(onClick = { cat.text = c }, label = { Text(c) }) }
            }
        }
        SField("Contraseña", pw, secret = true, reveal = reveal)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { reveal = !reveal }) { Text(if (reveal) "Ocultar" else "Mostrar") }
            if (strict && existing?.strict == true) {
                Text("Déjalo vacío para conservar el hash guardado.", fontSize = 12.sp)
            }
        }
        StrengthMeter(pw.text)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = strict, onCheckedChange = { strict = it })
            Spacer(Modifier.width(8.dp))
            Text("Modo estricto: guarda solo un hash (sin pistas ni retroalimentación detallada)", fontSize = 13.sp)
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { save() }, enabled = !busy) { Text(if (busy) "Guardando…" else "Guardar") }
            OutlinedButton(onClick = { close() }) { Text("Cancelar") }
        }
        if (existing != null) {
            TextButton(onClick = { confirmDelete = true }) {
                Text("Eliminar cuenta", color = MaterialTheme.colorScheme.error)
            }
        }
    }

    if (confirmDelete && existing != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar ${existing.name}?") },
            text = { Text("Se quita de la app. No cambia la cuenta real.") },
            confirmButton = {
                TextButton(onClick = { App.delete(existing.id); confirmDelete = false; close() }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}

// ------------------------------------------------------------ Stats

@Composable
fun StatsTab() {
    val seen = App.accounts.sumOf { it.seen }
    val correct = App.accounts.sumOf { it.correct }
    val sorted = App.accounts.sortedWith(
        compareBy<Account>({ it.seen == 0 }, { if (it.seen == 0) 0.0 else it.correct.toDouble() / it.seen })
    )
    LazyColumn(contentPadding = PaddingValues(16.dp)) {
        item {
            Text("Estadísticas", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text("🔥 Racha: ${App.currentStreak()} día(s)", fontSize = 18.sp)
            Text(
                if (seen == 0) "General: aún sin práctica" else "Aciertos al primer intento: ${correct * 100 / seen}% ($correct/$seen)",
                modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
            )
        }
        items(sorted, key = { it.id }) { a ->
            Column(Modifier.padding(vertical = 6.dp)) {
                Text(a.name + if (a.username.isNotBlank()) "  ·  ${a.username}" else "")
                if (a.seen == 0) {
                    Text("aún sin practicar", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LinearProgressIndicator(
                        progress = { a.correct.toFloat() / a.seen },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )
                    Text("${a.correct * 100 / a.seen}%  (${a.correct}/${a.seen})", fontSize = 12.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------ Settings

@Composable
fun SettingsTab() {
    val scope = rememberCoroutineScope()
    val p1 = remember { TextBuf() }
    val p2 = remember { TextBuf() }
    var show by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }

    fun change() {
        msg = ""
        if (p1.text.length < 8) {
            msg = "Usa al menos 8 caracteres."
        } else if (p1.text != p2.text) {
            msg = "Las contraseñas no coinciden."
        } else {
            busy = true
            App.kb.target = null
            scope.launch {
                App.changeMaster(p1.text)
                busy = false
                p1.text = ""
                p2.text = ""
                msg = "Contraseña maestra cambiada. Los respaldos viejos siguen usando la contraseña ANTERIOR."
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Ajustes", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = App.shuffleKeys, onCheckedChange = { App.setShuffle(it) })
            Spacer(Modifier.width(8.dp))
            Text("Mezclar las teclas (oculta tu patrón al escribir)")
        }
        Spacer(Modifier.height(16.dp))
        Text("Cambiar contraseña maestra", style = MaterialTheme.typography.titleMedium)
        SField("Nueva contraseña maestra", p1, secret = true, reveal = show)
        SField("Repite la nueva contraseña maestra", p2, secret = true, reveal = show)
        StrengthMeter(p1.text)
        Row {
            TextButton(onClick = { show = !show }) { Text(if (show) "Ocultar" else "Mostrar") }
            Button(onClick = { change() }, enabled = !busy && p1.text.isNotEmpty()) { Text("Cambiar") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Text("Respaldo", style = MaterialTheme.typography.titleMedium)
        Text(
            "Exporta el archivo cifrado de la bóveda. No sirve sin tu contraseña maestra. " +
                "Si lo guardas en una carpeta en la nube, esa copia sale de este celular.",
            fontSize = 13.sp
        )
        OutlinedButton(onClick = { App.launchExport() }) { Text("Exportar respaldo cifrado") }
        Spacer(Modifier.height(16.dp))
        Button(onClick = { App.lock() }) { Text("Bloquear ahora") }
        Spacer(Modifier.height(16.dp))
        Text("Seguridad", style = MaterialTheme.typography.titleMedium)
        Text(
            "• Sin ningún permiso (sin internet), verificado en cada compilación.\n" +
                "• Respaldo en la nube desactivado; capturas de pantalla bloqueadas.\n" +
                "• Teclado propio: ninguna otra app ve lo que escribes.\n" +
                "• La app se bloquea cada vez que sales de ella.",
            fontSize = 13.sp
        )
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = { confirmWipe = true }) {
            Text("Borrar TODOS los datos", color = MaterialTheme.colorScheme.error)
        }
    }

    if (confirmWipe) {
        AlertDialog(
            onDismissRequest = { confirmWipe = false },
            title = { Text("¿Borrar todo?") },
            text = { Text("La bóveda se borra de este celular. Sin respaldo no se puede recuperar.") },
            confirmButton = { TextButton(onClick = { confirmWipe = false; App.wipe() }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { confirmWipe = false }) { Text("Cancelar") } }
        )
    }
}
