package com.keywords.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.SecureRandom
import kotlin.math.ln

/** A text buffer that our own keyboard writes into. The system keyboard is never used. */
class TextBuf(initial: String = "") {
    var text by mutableStateOf(initial)
}

class KbController {
    var target by mutableStateOf<TextBuf?>(null)
}

private val L0 = listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnmñ")
private val L1 = listOf("1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNMÑ")
private val L2 = listOf("!@#$%^&*()", "-_=+[]{};:", "'\"\\|,.<>/?", "`~¿¡€£¥°·")

private fun buildRows(layer: Int, shuffle: Boolean): List<List<Char>> {
    val base = when (layer) { 0 -> L0; 1 -> L1; else -> L2 }
    if (!shuffle) return base.map { it.toList() }
    val all = base.joinToString("").toMutableList()
    all.shuffle(SecureRandom())
    var i = 0
    return base.map { r -> List(r.length) { all[i++] } }
}

@Composable
fun SecureKeyboard(target: TextBuf, shuffle: Boolean, onDone: () -> Unit) {
    var layer by remember { mutableIntStateOf(0) } // 0 lower, 1 upper, 2 symbols
    val rows = remember(layer, target, shuffle) { buildRows(layer, shuffle) }
    Column(Modifier.fillMaxWidth().background(Color(0xFF1B1B1B)).padding(4.dp)) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { ch ->
                    KbKey(ch.toString(), Modifier.weight(1f)) {
                        target.text = target.text + ch
                        if (layer == 1) layer = 0
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth()) {
            KbKey(if (layer == 2) "abc" else "?123", Modifier.weight(1.4f)) { layer = if (layer == 2) 0 else 2 }
            KbKey("⇧", Modifier.weight(1f)) { layer = if (layer == 1) 0 else 1 }
            KbKey("espacio", Modifier.weight(3f)) { target.text = target.text + " " }
            KbKey("⌫", Modifier.weight(1.2f)) {
                if (target.text.isNotEmpty()) target.text = target.text.dropLast(1)
            }
            KbKey("Listo", Modifier.weight(1.4f), accent = true) { onDone() }
        }
    }
}

@Composable
private fun KbKey(label: String, modifier: Modifier, accent: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier
            .padding(2.dp)
            .height(46.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (accent) Color(0xFF00695C) else Color(0xFF383838))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 17.sp)
    }
}

/** Display-only field. Tapping it points our keyboard at this buffer. */
@Composable
fun SField(label: String, buf: TextBuf, secret: Boolean = false, reveal: Boolean = false) {
    val active = App.kb.target === buf
    val shape = RoundedCornerShape(8.dp)
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Box(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 48.dp)
                .clip(shape)
                .border(
                    if (active) 2.dp else 1.dp,
                    if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    shape
                )
                .clickable { App.kb.target = buf }
                .padding(12.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            val shown = if (secret && !reveal) "•".repeat(buf.text.length) else buf.text
            Text(shown + if (active) "│" else "", fontFamily = FontFamily.Monospace, fontSize = 16.sp)
        }
    }
}

fun strengthBits(p: String): Double {
    if (p.isEmpty()) return 0.0
    var pool = 0
    if (p.any { it.isLowerCase() }) pool += 26
    if (p.any { it.isUpperCase() }) pool += 26
    if (p.any { it.isDigit() }) pool += 10
    if (p.any { !it.isLetterOrDigit() }) pool += 32
    if (pool == 0) pool = 26
    val effLen = minOf(p.length, p.toSet().size * 2)
    var bits = effLen * ln(pool.toDouble()) / ln(2.0)
    val low = p.lowercase()
    if (listOf("password", "123456", "qwerty", "abc", "admin", "letmein", "contrase").any { low.contains(it) }) bits *= 0.5
    return bits
}

@Composable
fun StrengthMeter(p: String) {
    if (p.isEmpty()) return
    val bits = strengthBits(p)
    val (label, color) = when {
        bits < 28 -> "Muy débil" to Color(0xFFE53935)
        bits < 40 -> "Débil" to Color(0xFFFB8C00)
        bits < 60 -> "Regular" to Color(0xFFFDD835)
        bits < 80 -> "Fuerte" to Color(0xFF7CB342)
        else -> "Muy fuerte" to Color(0xFF43A047)
    }
    Column(Modifier.padding(vertical = 4.dp)) {
        LinearProgressIndicator(
            progress = { (bits / 100.0).coerceIn(0.05, 1.0).toFloat() },
            color = color,
            modifier = Modifier.fillMaxWidth()
        )
        Text("Seguridad: $label (~${bits.toInt()} bits)", fontSize = 12.sp)
    }
}
