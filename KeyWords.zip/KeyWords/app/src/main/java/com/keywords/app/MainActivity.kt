package com.keywords.app

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {

    private val exportLauncher =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(App.exportBytes()) }
                    Toast.makeText(this, "Respaldo cifrado guardado", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "No se pudo guardar el respaldo", Toast.LENGTH_LONG).show()
                }
            }
        }

    private val importLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (bytes != null && bytes.size < 5_000_000) {
                        App.pendingImport = bytes
                    } else {
                        Toast.makeText(this, "Archivo de respaldo inválido", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "No se pudo leer el archivo", Toast.LENGTH_LONG).show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots, screen recording and the preview in the recent-apps list.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        App.init(applicationContext)
        App.launchExport = {
            App.skipNextLock = true
            exportLauncher.launch("keywords-backup.kwv")
        }
        App.launchImport = {
            App.skipNextLock = true
            importLauncher.launch(arrayOf("*/*"))
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF80CBC4),
                    onPrimary = Color(0xFF00201D)
                )
            ) {
                Surface(Modifier.fillMaxSize()) { Root() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        App.skipNextLock = false
    }

    // Lock the vault whenever the app leaves the screen.
    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !App.skipNextLock) App.lock()
    }
}

@Composable
private fun Root() {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            when (val s = App.screen) {
                is Screen.Auth -> AuthScreen()
                is Screen.Home -> HomeScreen()
                is Screen.Edit -> EditScreen(s.id)
                is Screen.Session -> SessionScreen(s.cfg)
            }
        }
        App.kb.target?.let { t ->
            SecureKeyboard(t, App.shuffleKeys) { App.kb.target = null }
        }
    }
}
