package com.keywords.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.time.LocalDate

data class Account(
    val id: String,
    val name: String,
    val username: String,
    val category: String,
    val strict: Boolean,
    val password: String,
    val salt: String,
    val hash: String,
    val seen: Int = 0,
    val correct: Int = 0
)

enum class Tab(val icon: String, val label: String) {
    ACCOUNTS("🗂", "Cuentas"),
    PRACTICE("🎯", "Práctica"),
    STATS("📊", "Estadísticas"),
    SETTINGS("⚙", "Ajustes")
}

sealed class Screen {
    object Auth : Screen()
    object Home : Screen()
    data class Edit(val id: String?) : Screen()
    data class Session(val cfg: SessionConfig) : Screen()
}

object App {
    private const val MAGIC = "KW1"

    lateinit var file: File
    lateinit var prefs: SharedPreferences

    var unlocked by mutableStateOf(false)
    var screen by mutableStateOf<Screen>(Screen.Auth)
    var tab by mutableStateOf(Tab.ACCOUNTS)
    val accounts = mutableStateListOf<Account>()
    var streak by mutableIntStateOf(0)
    var lastDay by mutableLongStateOf(0L)
    var pendingImport by mutableStateOf<ByteArray?>(null)
    var shuffleKeys by mutableStateOf(false)
    val kb = KbController()

    var skipNextLock = false
    var launchExport: () -> Unit = {}
    var launchImport: () -> Unit = {}

    private var key: ByteArray? = null
    private var salt: ByteArray = ByteArray(16)
    private var iter: Int = Crypto.VAULT_ITER

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "vault.kw")
        prefs = ctx.getSharedPreferences("kw", Context.MODE_PRIVATE)
        shuffleKeys = prefs.getBoolean("shuffle", false)
    }

    fun setShuffle(b: Boolean) {
        shuffleKeys = b
        prefs.edit().putBoolean("shuffle", b).apply()
    }

    fun vaultExists(): Boolean = file.exists()

    // ---------- file format: "KW1" | salt(16) | iterations(4) | iv(12) | ciphertext+tag ----------
    private class Parsed(val salt: ByteArray, val iter: Int, val header: ByteArray, val body: ByteArray)

    private fun parse(b: ByteArray): Parsed? {
        if (b.size < 3 + 16 + 4 + 12 + 16) return null
        if (String(b, 0, 3, Charsets.US_ASCII) != MAGIC) return null
        val iters = ByteBuffer.wrap(b, 19, 4).int
        if (iters < 100_000 || iters > 5_000_000) return null
        return Parsed(b.copyOfRange(3, 19), iters, b.copyOfRange(0, 23), b.copyOfRange(23, b.size))
    }

    private fun header(): ByteArray =
        MAGIC.toByteArray(Charsets.US_ASCII) + salt + ByteBuffer.allocate(4).putInt(iter).array()

    private fun serialize(): ByteArray {
        val arr = JSONArray()
        for (a in accounts) {
            arr.put(
                JSONObject()
                    .put("id", a.id).put("name", a.name).put("username", a.username)
                    .put("category", a.category).put("strict", a.strict)
                    .put("password", a.password).put("salt", a.salt).put("hash", a.hash)
                    .put("seen", a.seen).put("correct", a.correct)
            )
        }
        val o = JSONObject().put("streak", streak).put("lastDay", lastDay).put("accounts", arr)
        return o.toString().toByteArray(Charsets.UTF_8)
    }

    private fun load(plain: ByteArray) {
        val o = JSONObject(String(plain, Charsets.UTF_8))
        val arr = o.getJSONArray("accounts")
        val list = ArrayList<Account>()
        for (i in 0 until arr.length()) {
            val j = arr.getJSONObject(i)
            list.add(
                Account(
                    id = j.getString("id"), name = j.getString("name"),
                    username = j.optString("username", ""), category = j.optString("category", ""),
                    strict = j.optBoolean("strict", false), password = j.optString("password", ""),
                    salt = j.optString("salt", ""), hash = j.optString("hash", ""),
                    seen = j.optInt("seen", 0), correct = j.optInt("correct", 0)
                )
            )
        }
        accounts.clear()
        accounts.addAll(list)
        streak = o.optInt("streak", 0)
        lastDay = o.optLong("lastDay", 0L)
    }

    fun persist() {
        val k = key ?: return
        val h = header()
        val out = h + Crypto.encrypt(k, serialize(), h)
        val tmp = File(file.parentFile, "vault.tmp")
        tmp.writeBytes(out)
        if (!tmp.renameTo(file)) {
            file.writeBytes(out)
            tmp.delete()
        }
    }

    private fun finishUnlock() {
        unlocked = true
        tab = Tab.ACCOUNTS
        screen = Screen.Home
    }

    // ---------- vault lifecycle ----------
    suspend fun setup(pw: String) {
        val s = Crypto.random(16)
        val k = withContext(Dispatchers.Default) { Crypto.pbkdf2(pw, s, Crypto.VAULT_ITER) }
        salt = s
        iter = Crypto.VAULT_ITER
        key = k
        accounts.clear()
        streak = 0
        lastDay = 0L
        persist()
        finishUnlock()
    }

    suspend fun unlock(pw: String): Boolean {
        val imported = pendingImport
        val bytes: ByteArray = imported ?: (if (file.exists()) file.readBytes() else null) ?: return false
        val p = parse(bytes) ?: return false
        val k = withContext(Dispatchers.Default) { Crypto.pbkdf2(pw, p.salt, p.iter) }
        val plain = Crypto.decrypt(k, p.body, p.header) ?: return false
        load(plain)
        salt = p.salt
        iter = p.iter
        key = k
        if (imported != null) {
            file.writeBytes(bytes)
            pendingImport = null
        }
        finishUnlock()
        return true
    }

    fun lock() {
        key?.fill(0)
        key = null
        accounts.clear()
        streak = 0
        lastDay = 0L
        kb.target = null
        PP.reset()
        unlocked = false
        screen = Screen.Auth
    }

    suspend fun changeMaster(newPw: String) {
        val s = Crypto.random(16)
        val k = withContext(Dispatchers.Default) { Crypto.pbkdf2(newPw, s, Crypto.VAULT_ITER) }
        key?.fill(0)
        salt = s
        iter = Crypto.VAULT_ITER
        key = k
        persist()
    }

    fun wipe() {
        file.delete()
        lock()
    }

    fun exportBytes(): ByteArray {
        persist()
        return file.readBytes()
    }

    // ---------- accounts ----------
    fun upsert(a: Account) {
        val i = accounts.indexOfFirst { it.id == a.id }
        if (i >= 0) accounts[i] = a else {
            accounts.add(a)
            if (PP.inited) PP.selected.add(a.id)
        }
        persist()
    }

    fun delete(id: String) {
        accounts.removeAll { it.id == id }
        PP.selected.remove(id)
        persist()
    }

    suspend fun makeStrict(a: Account, pw: String): Account = withContext(Dispatchers.Default) {
        val s = Crypto.random(16)
        a.copy(strict = true, password = "", salt = Crypto.b64(s), hash = Crypto.b64(Crypto.pbkdf2(pw, s, Crypto.ACCOUNT_ITER)))
    }

    suspend fun matches(a: Account, input: String): Boolean = withContext(Dispatchers.Default) {
        if (!a.strict) {
            Crypto.same(a.password.toByteArray(Charsets.UTF_8), input.toByteArray(Charsets.UTF_8))
        } else {
            Crypto.same(Crypto.pbkdf2(input, Crypto.unb64(a.salt), Crypto.ACCOUNT_ITER), Crypto.unb64(a.hash))
        }
    }

    fun record(id: String, ok: Boolean) {
        val i = accounts.indexOfFirst { it.id == id }
        if (i < 0) return
        val a = accounts[i]
        accounts[i] = a.copy(seen = a.seen + 1, correct = a.correct + if (ok) 1 else 0)
        val today = LocalDate.now().toEpochDay()
        if (lastDay != today) {
            streak = if (lastDay == today - 1) streak + 1 else 1
            lastDay = today
        }
        persist()
    }

    fun currentStreak(): Int {
        val today = LocalDate.now().toEpochDay()
        return if (lastDay >= today - 1) streak else 0
    }
}
